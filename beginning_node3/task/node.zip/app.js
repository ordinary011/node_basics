let express = require('express');
let path = require('path');

let app = express();

app.use(express.static(path.join(__dirname, 'static')));

app.use(express.urlencoded({extended: true}));
app.use(express.json());

app.get('/', function (req, res) {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/about', function (req, res) {
    res.sendFile(path.join(__dirname, 'public', 'about.html'));
});


//GET -> req.query
//POST -> req.body
app.post('/sendForm', function (req, res) {
    res.end(JSON.stringify(req.body));
});

app.listen(3000, function () {
    console.log('Listening...');
});
